package com.schoolStudents.schoolStudents;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SchoolStudentsApplicationTests {

	@Test
	void contextLoads() {
	}

}
